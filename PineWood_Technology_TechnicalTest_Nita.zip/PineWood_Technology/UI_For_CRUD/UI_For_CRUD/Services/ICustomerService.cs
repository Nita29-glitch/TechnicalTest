﻿
using UI_For_CRUD.Models;

public interface ICustomerService
{
    Task<List<Customer>> GetCustomers();
    Task<Customer> GetCustomer(int id);
    Task AddCustomer(Customer customer);
    Task UpdateCustomer(Customer customer);
    Task DeleteCustomer(int id);

}
