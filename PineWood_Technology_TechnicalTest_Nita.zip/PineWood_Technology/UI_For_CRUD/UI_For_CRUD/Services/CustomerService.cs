﻿
using UI_For_CRUD.Models;
public class CustomerService : ICustomerService
{
    private readonly HttpClient _httpClient;

    public CustomerService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }
    //Get the api call to view customer 
    public async Task<List<Customer>> GetCustomers()
    {
        return await _httpClient.GetFromJsonAsync<List<Customer>>("https://localhost:7219/api/customer");
    }
    //Get the api call to view customer by Id 
    public async Task<Customer> GetCustomer(int id)
    {        
        return await _httpClient.GetFromJsonAsync<Customer>($"https://localhost:7219/api/customer/{id}");
    }
    //Get the api call to inert the customer 
    public async Task AddCustomer(Customer customer)
    {
        await _httpClient.PostAsJsonAsync("https://localhost:7219/api/customer", customer);
    }
   
    //Get the api call to update the customer details by Id
    public async Task UpdateCustomer(Customer customer)
    {
        await _httpClient.PutAsJsonAsync($"https://localhost:7219/api/customer/{customer.Id}", customer);
    }
    //Get the api call to delete the customer
    public async Task DeleteCustomer(int id)
    {
        await _httpClient.DeleteAsync($"https://localhost:7219/api/customer/{id}");
    }
}
