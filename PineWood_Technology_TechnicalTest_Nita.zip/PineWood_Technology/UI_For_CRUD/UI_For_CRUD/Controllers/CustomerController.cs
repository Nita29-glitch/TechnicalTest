﻿
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using UI_For_CRUD.Models;

public class CustomerController : Controller
{
    private readonly ICustomerService _customerService;

    public CustomerController(ICustomerService customerService)
    {
        _customerService = customerService;
    }

    // GET: Customer
    public async Task<IActionResult> Index()
    {
        var customers = await _customerService.GetCustomers();
        return View(customers);
    }

    // GET: Customer/Create
    public IActionResult Create()
    {
        return View();
    }

    // POST: Customer/Create
    [HttpPost]
    public async Task<IActionResult> Create(Customer customer)
    {
        if (ModelState.IsValid)
        {
            await _customerService.AddCustomer(customer);
            return RedirectToAction(nameof(Index));
        }
        return View(customer);
    }

    // GET: Customer/Edit/{id}
    public async Task<IActionResult> Edit(int id)
    {
        var customer = await _customerService.GetCustomer(id);
        if (customer == null)
        {
            return NotFound();
        }
        return View(customer);
    }

    // POST: Customer/Edit/{id}
    [HttpPost]
    public async Task<IActionResult> Edit(int id, Customer customer)
    {
        if (id != customer.Id)
        {
            return BadRequest();
        }

        if (ModelState.IsValid)
        {
            await _customerService.UpdateCustomer(customer);
            return RedirectToAction(nameof(Index));
        }
        return View(customer);
    }

    // GET: Customer/Delete/{id}
    public async Task<IActionResult> Delete(int id)
    {
        var customer = await _customerService.GetCustomer(id);
        if (customer == null)
        {
            return NotFound();
        }
        return View(customer);
    }

    // POST: Customer/DeleteConfirmed/{id}
    [HttpPost, ActionName("DeleteConfirmed")]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        await _customerService.DeleteCustomer(id);
        return RedirectToAction(nameof(Index));
    }
}
