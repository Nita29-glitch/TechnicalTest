﻿using Microsoft.EntityFrameworkCore;
using API_For_BackEnd.Models;

public class CustomerContext : DbContext
{
    public CustomerContext(DbContextOptions<CustomerContext> options) : base(options) { }

    public DbSet<Customer> Customers { get; set; }
}
